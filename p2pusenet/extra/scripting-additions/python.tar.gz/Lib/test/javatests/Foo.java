package javatests;

public class Foo {};
