# A test for PR#239, escaping a quote inside a triple quoted string.

s = r""" 
    \""" 1.triple-quote
    \""" 2.triple-quote
"""
