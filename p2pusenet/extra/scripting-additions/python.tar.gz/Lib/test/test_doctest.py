import doctest, test_support
test_support.run_doctest(doctest)
