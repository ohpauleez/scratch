#
#   version.rb - shell version definition file
#   	$Release Version: 0.6.0$
#   	$Revision: 2062 $
#   	$Date: 2006-06-10 14:14:15 -0500 (Sat, 10 Jun 2006) $
#   	by Keiju ISHITSUKA(Nihon Rational Software Co.,Ltd)
#
# --
#
#   
#

class Shell
  @RELEASE_VERSION = "0.6.0"
  @LAST_UPDATE_DATE = "01/03/19"
end
