from test_support import TestSkipped

raise TestSkipped, 'test_poll currently not supported in Jython'
